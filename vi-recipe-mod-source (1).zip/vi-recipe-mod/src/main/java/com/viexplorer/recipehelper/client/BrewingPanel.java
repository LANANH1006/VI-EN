package com.viexplorer.recipehelper.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.BrewingStandScreen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Bảng công thức bên phải giàn chế thuốc: thanh tìm kiếm ở trên, danh sách cuộn bên dưới,
 * mỗi công thức hiển thị bằng icon 2D: [thuốc gốc] + [nguyên liệu] = [thuốc kết quả].
 */
public final class BrewingPanel {

    private static final int PANEL_W = 150;
    private static final int PANEL_H = 166;
    private static final int SEARCH_H = 14;
    private static final int LIST_TOP = 34;
    private static final int ROW_H = 30;

    private static String query = "";
    private static boolean searchFocused = true;
    private static int scroll = 0;

    private BrewingPanel() {}

    public static void reset() {
        query = "";
        searchFocused = true;
        scroll = 0;
    }

    /** Đúng khi người chơi đang ở màn hình giàn chế thuốc và ô tìm kiếm đang được chọn. */
    public static boolean isTypingInSearch() {
        return searchFocused && MinecraftClient.getInstance().currentScreen instanceof BrewingStandScreen;
    }

    private static int panelX(int screenW) {
        return screenW / 2 + 96;
    }

    private static int panelY(int screenH) {
        return screenH / 2 - PANEL_H / 2;
    }

    public static void render(DrawContext ctx, TextRenderer tr, int screenW, int screenH, int mouseX, int mouseY) {
        int x = panelX(screenW);
        int y = panelY(screenH);

        ctx.fill(x, y, x + PANEL_W, y + PANEL_H, 0xD0101010);
        ctx.drawBorder(x, y, PANEL_W, PANEL_H, 0xFF8B8B8B);

        // Ô tìm kiếm
        int sx = x + 4, sy = y + 4, sw = PANEL_W - 8;
        ctx.fill(sx, sy, sx + sw, sy + SEARCH_H, searchFocused ? 0xFF3A3A3A : 0xFF202020);
        ctx.drawBorder(sx, sy, sw, SEARCH_H, searchFocused ? 0xFFFFFFFF : 0xFF555555);
        if (query.isEmpty() && !searchFocused) {
            ctx.drawText(tr, "Tìm công thức...", sx + 3, sy + 3, 0xFF777777, false);
        } else {
            String shown = tr.trimToWidth(query, sw - 8);
            if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) {
                shown = shown + "_";
            }
            ctx.drawText(tr, shown, sx + 3, sy + 3, 0xFFFFFFFF, false);
        }

        List<BrewingData.Entry> list = BrewingData.search(query);
        ctx.drawText(tr, "Công thức: " + list.size(), x + 4, y + 22, 0xFFAAAAAA, false);

        int listH = PANEL_H - LIST_TOP - 4;
        int visible = Math.max(1, listH / ROW_H);
        int maxScroll = Math.max(0, list.size() - visible);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        int listX1 = x + 2, listY1 = y + LIST_TOP, listX2 = x + PANEL_W - 2, listY2 = listY1 + listH;
        ctx.enableScissor(listX1, listY1, listX2, listY2);

        BrewingData.Entry hovered = null;
        int hoveredRow = -1;
        for (int i = scroll; i < Math.min(list.size(), scroll + visible + 1); i++) {
            int ry = listY1 + (i - scroll) * ROW_H;
            BrewingData.Entry e = list.get(i);
            boolean hover = mouseX >= listX1 && mouseX < listX2 && mouseY >= ry && mouseY < ry + ROW_H;
            if (hover) {
                hovered = e;
                hoveredRow = i;
                ctx.fill(listX1, ry, listX2, ry + ROW_H, 0x40FFFFFF);
            }
            drawRow(ctx, tr, e, x + 6, ry);
        }
        ctx.disableScissor();

        // Thanh cuộn
        if (maxScroll > 0) {
            int barH = Math.max(12, listH * visible / list.size());
            int barY = listY1 + (listH - barH) * scroll / maxScroll;
            ctx.fill(x + PANEL_W - 4, barY, x + PANEL_W - 2, barY + barH, 0xFFAAAAAA);
        }

        if (hovered != null && hoveredRow >= 0) {
            ctx.drawTooltip(tr, List.of(
                    Text.literal("Kết quả: " + hovered.viResult()),
                    Text.literal("Nguyên liệu: " + hovered.ingredient().getName().getString()),
                    Text.literal("Thuốc gốc: " + hovered.base().getName().getString())
            ), mouseX, mouseY);
        }
    }

    /** Một dòng: [gốc] + [nguyên liệu] = [kết quả], nhãn tiếng Việt bên dưới. */
    private static void drawRow(DrawContext ctx, TextRenderer tr, BrewingData.Entry e, int x, int y) {
        ctx.drawItem(e.base(), x, y + 2);
        ctx.drawText(tr, "+", x + 19, y + 6, 0xFFFFFFFF, false);
        ctx.drawItem(e.ingredient(), x + 27, y + 2);
        ctx.drawText(tr, "=", x + 46, y + 6, 0xFFFFFFFF, false);
        ctx.drawItem(e.result(), x + 54, y + 2);
        String label = tr.trimToWidth(e.viResult(), PANEL_W - 14);
        ctx.drawText(tr, label, x, y + 19, 0xFFDDDDDD, false);
        ctx.fill(x - 2, y + ROW_H - 1, x + PANEL_W - 14, y + ROW_H, 0x30FFFFFF);
    }

    /** Trả về true nếu chuột đã được xử lý bởi bảng này (để chặn tương tác khác). */
    public static boolean click(int screenW, int screenH, double mouseX, double mouseY) {
        int x = panelX(screenW), y = panelY(screenH);
        if (!inside(mouseX, mouseY, x, y, PANEL_W, PANEL_H)) {
            searchFocused = false;
            return false;
        }
        searchFocused = inside(mouseX, mouseY, x + 4, y + 4, PANEL_W - 8, SEARCH_H);
        return true;
    }

    public static boolean scroll(int screenW, int screenH, double mouseX, double mouseY, double vertical) {
        int x = panelX(screenW), y = panelY(screenH);
        if (!inside(mouseX, mouseY, x, y, PANEL_W, PANEL_H)) {
            return false;
        }
        scroll -= (int) Math.signum(vertical);
        if (scroll < 0) scroll = 0;
        return true;
    }

    /** Nhận ký tự gõ vào khi ô tìm kiếm đang được chọn. */
    public static boolean charTyped(char chr) {
        if (!isTypingInSearch() || Character.isISOControl(chr)) {
            return false;
        }
        query = query + chr;
        scroll = 0;
        return true;
    }

    /** Xử lý phím khi đang gõ tìm kiếm. Trả về true để chặn phím tắt của game (ví dụ phím E đóng màn hình). */
    public static boolean keyPressed(int keyCode) {
        if (!isTypingInSearch()) {
            return false;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            return false; // ESC vẫn đóng màn hình như bình thường
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            if (!query.isEmpty()) {
                query = query.substring(0, query.length() - 1);
                scroll = 0;
            }
        }
        return true;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
