package com.viexplorer.recipehelper.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Bảng bên phải bàn phù phép: liệt kê TẤT CẢ phép có thể áp dụng cho vật phẩm đang đặt vào,
 * kèm cấp tối đa. (Ba lựa chọn ngẫu nhiên của bàn không đoán trước được nên không hiển thị ở đây.)
 */
public final class EnchantPanel {

    private static final int PANEL_W = 150;
    private static final int PANEL_H = 166;
    private static final int LIST_TOP = 34;
    private static final int ROW_H = 12;

    private static int scroll = 0;
    private static ItemStack lastStack = ItemStack.EMPTY;
    private static List<Text> lines = new ArrayList<>();

    private EnchantPanel() {}

    public static void reset() {
        scroll = 0;
        lastStack = ItemStack.EMPTY;
        lines = new ArrayList<>();
    }

    private static void rebuild(MinecraftClient client, ItemStack stack) {
        List<Text> out = new ArrayList<>();
        if (!stack.isEmpty() && client.world != null) {
            Registry<Enchantment> registry = client.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
            for (Enchantment ench : registry) {
                if (ench.isAcceptableItem(stack)) {
                    out.add(ench.description().copy().append(Text.literal("  max " + ench.getMaxLevel())));
                }
            }
        }
        lines = out;
        lastStack = stack.copy();
        scroll = 0;
    }

    public static void render(DrawContext ctx, TextRenderer tr, MinecraftClient client, ItemStack stack,
                              int screenW, int screenH, int mouseX, int mouseY) {
        if (!ItemStack.areItemsEqual(stack, lastStack)) {
            rebuild(client, stack);
        }

        int x = screenW / 2 + 96;
        int y = screenH / 2 - PANEL_H / 2;
        ctx.fill(x, y, x + PANEL_W, y + PANEL_H, 0xD0101010);
        ctx.drawBorder(x, y, PANEL_W, PANEL_H, 0xFF8B8B8B);

        if (stack.isEmpty()) {
            ctx.drawText(tr, "Đặt vật phẩm vào ô", x + 6, y + 8, 0xFFAAAAAA, false);
            ctx.drawText(tr, "bên trái để xem", x + 6, y + 18, 0xFFAAAAAA, false);
            ctx.drawText(tr, "các phép áp dụng được.", x + 6, y + 28, 0xFFAAAAAA, false);
            return;
        }

        ctx.drawText(tr, "Phép áp dụng được: " + lines.size(), x + 4, y + 6, 0xFFFFFFFF, false);
        ctx.drawText(tr, stack.getName().getString(), x + 4, y + 18, 0xFFFFD700, false);

        int listH = PANEL_H - LIST_TOP - 4;
        int visible = Math.max(1, listH / ROW_H);
        int maxScroll = Math.max(0, lines.size() - visible);
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        int lx1 = x + 2, ly1 = y + LIST_TOP, lx2 = x + PANEL_W - 2, ly2 = ly1 + listH;
        ctx.enableScissor(lx1, ly1, lx2, ly2);
        for (int i = scroll; i < Math.min(lines.size(), scroll + visible + 1); i++) {
            int ry = ly1 + (i - scroll) * ROW_H;
            String label = tr.trimToWidth(lines.get(i).getString(), PANEL_W - 10);
            ctx.drawText(tr, label, x + 5, ry + 2, 0xFFDDDDDD, false);
        }
        ctx.disableScissor();

        if (maxScroll > 0) {
            int barH = Math.max(12, listH * visible / lines.size());
            int barY = ly1 + (listH - barH) * scroll / maxScroll;
            ctx.fill(x + PANEL_W - 4, barY, x + PANEL_W - 2, barY + barH, 0xFFAAAAAA);
        }
    }

    /** Cuộn danh sách phép. Trả về true nếu chuột nằm trong bảng. */
    public static boolean scroll(int screenW, int screenH, double mouseX, double mouseY, double vertical) {
        int x = screenW / 2 + 96;
        int y = screenH / 2 - PANEL_H / 2;
        if (mouseX < x || mouseX >= x + PANEL_W || mouseY < y || mouseY >= y + PANEL_H) {
            return false;
        }
        scroll -= (int) Math.signum(vertical);
        if (scroll < 0) scroll = 0;
        return true;
    }
}
