package com.viexplorer.recipehelper.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.SmithingScreen;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.util.math.RotationAxis;

/**
 * Bảng bên phải bàn nâng cấp: hiện 3 ô nguyên liệu (icon 2D) và khung xem trước 3D của vật phẩm kết quả.
 * Kéo chuột trái trong khung 3D để xoay 360 độ.
 */
public final class SmithingPanel {

    private static final int PANEL_W = 150;
    private static final int PANEL_H = 166;
    private static final int PREVIEW_H = 92;
    private static final int TEMPLATE_SLOT = 0;
    private static final int BASE_SLOT = 1;
    private static final int ADDITION_SLOT = 2;
    private static final int OUTPUT_SLOT = 3;

    private static float angleX = 15f;
    private static float angleY = 30f;
    private static boolean dragging = false;

    private SmithingPanel() {}

    public static void reset() {
        angleX = 15f;
        angleY = 30f;
        dragging = false;
    }

    private static int panelX(int screenW) {
        return screenW / 2 + 96;
    }

    private static int panelY(int screenH) {
        return screenH / 2 - PANEL_H / 2;
    }

    public static void render(DrawContext ctx, TextRenderer tr, MinecraftClient client, ScreenHandler handler,
                              int screenW, int screenH) {
        int x = panelX(screenW);
        int y = panelY(screenH);
        ctx.fill(x, y, x + PANEL_W, y + PANEL_H, 0xD0101010);
        ctx.drawBorder(x, y, PANEL_W, PANEL_H, 0xFF8B8B8B);
        ctx.drawText(tr, "Xem trước nâng cấp", x + 4, y + 6, 0xFFFFFFFF, false);

        // Ba ô nguyên liệu, vẽ bằng icon 2D
        int iy = y + 20;
        int[] slots = {TEMPLATE_SLOT, BASE_SLOT, ADDITION_SLOT};
        String[] labels = {"Khuôn", "Gốc", "Thêm"};
        for (int i = 0; i < slots.length; i++) {
            int ix = x + 8 + i * 46;
            ItemStack s = handler.getSlot(slots[i]).getStack();
            ctx.fill(ix - 1, iy - 1, ix + 17, iy + 17, 0x40FFFFFF);
            ctx.drawItem(s, ix, iy);
            ctx.drawText(tr, labels[i], ix - 2, iy + 19, 0xFFAAAAAA, false);
        }

        // Khung xem trước 3D
        int px = x + 4, py = y + 52, pw = PANEL_W - 8;
        ctx.fill(px, py, px + pw, py + PREVIEW_H, 0xFF151515);
        ctx.drawBorder(px, py, pw, PREVIEW_H, 0xFF555555);

        ItemStack out = handler.getSlot(OUTPUT_SLOT).getStack();
        if (out.isEmpty()) {
            ctx.drawText(tr, "Đặt đủ nguyên liệu", px + 14, py + 40, 0xFF888888, false);
            ctx.drawText(tr, "để xem kết quả 3D", px + 17, py + 50, 0xFF888888, false);
        } else {
            ctx.enableScissor(px + 1, py + 1, px + pw - 1, py + PREVIEW_H - 1);
            renderModel3D(ctx, client, out, px + pw / 2, py + PREVIEW_H / 2 + 4);
            ctx.disableScissor();
            ctx.drawText(tr, "Kéo chuột để xoay", px + 4, py + PREVIEW_H - 10, 0xFF777777, false);
            ctx.drawText(tr, tr.trimToWidth(out.getName().getString(), PANEL_W - 8),
                    x + 4, y + PANEL_H - 12, 0xFFFFD700, false);
        }
    }

    /** Vẽ vật phẩm dạng 3D tại (cx, cy), có xoay theo góc hiện tại. */
    private static void renderModel3D(DrawContext ctx, MinecraftClient client, ItemStack stack, int cx, int cy) {
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, cy, 150.0);
        m.scale(56.0f, -56.0f, 56.0f);
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(angleX));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(angleY));
        client.getItemRenderer().renderItem(
                stack,
                ModelTransformationMode.GUI,
                LightmapTextureManager.MAX_LIGHT_COORDINATE,
                OverlayTexture.DEFAULT_UV,
                m,
                ctx.getVertexConsumers(),
                client.world,
                0
        );
        m.pop();
        ctx.draw();
    }

    /** Gọi khi nhấn chuột: bắt đầu xoay nếu nhấn bên trong khung 3D. */
    public static void press(int screenW, int screenH, double mouseX, double mouseY) {
        int px = panelX(screenW) + 4;
        int py = panelY(screenH) + 52;
        dragging = mouseX >= px && mouseX < px + PANEL_W - 8 && mouseY >= py && mouseY < py + PREVIEW_H;
    }

    /** Gọi khi kéo chuột. Trả về true nếu đang xoay mô hình (để chặn xử lý khác). */
    public static boolean drag(double deltaX, double deltaY) {
        if (!dragging || !(MinecraftClient.getInstance().currentScreen instanceof SmithingScreen)) {
            return false;
        }
        angleY += (float) deltaX * 1.2f;
        angleX += (float) deltaY * 1.2f;
        if (angleX > 89f) angleX = 89f;
        if (angleX < -89f) angleX = -89f;
        return true;
    }
}
